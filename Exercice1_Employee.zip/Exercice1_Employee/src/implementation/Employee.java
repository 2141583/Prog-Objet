package implementation;

import java.security.InvalidParameterException;

public class Employee {
	
	private String name;
	private int employeeNumber;
	private float annualSalary;
	
	public static final float MAX_SALARY = 100000;
	public static final String INVALID_PARAMETER_NUMBER_1 = "Un nouvel employ� ne peut pas recevoir un salaire annuel sup�rieur � 100 000$.";

	public Employee(String name, int employeeNumber, float annualSalary) {
		if (annualSalary > MAX_SALARY) throw new InvalidParameterException(INVALID_PARAMETER_NUMBER_1);
		this.name = name;
		this.employeeNumber = employeeNumber;
		this.annualSalary = annualSalary;
	}

	public String getName() {
		return this.name;
	}
	public int getEmployeeNumber() {
		return this.employeeNumber;
	}
	public float getAnnualSalary() {
		return this.annualSalary;
	}

}
