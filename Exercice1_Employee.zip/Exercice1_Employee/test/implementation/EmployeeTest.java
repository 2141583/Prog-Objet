package implementation;

import static org.junit.jupiter.api.Assertions.*;

import java.security.InvalidParameterException;

import org.junit.jupiter.api.Test;

class EmployeeTest {
	
	private static final String ANY_NAME = "Bob";
	private static final int ANY_EMPLOYEE_NUMBER = 12345;
	private static final float ANY_ANNUAL_SALARY = 100000;
	private static final float NOT_VALID_ANNUAL_SALARY = 100005;
	
	@Test
	void createEmployeeNameShouldBeInitialize() {
		//Arrange
		
		//Act
		Employee employee = new Employee(ANY_NAME, ANY_EMPLOYEE_NUMBER, ANY_ANNUAL_SALARY);
		
		//Assert
		assertEquals(ANY_NAME, employee.getName());
		
	}
	@Test
	void createEmployeeNumberAndSalaryShouldBeInitialize() {
		//Arrange
		
		//Act
		Employee employee = new Employee(ANY_NAME, ANY_EMPLOYEE_NUMBER, ANY_ANNUAL_SALARY);
		
		//Assert
		assertEquals(ANY_EMPLOYEE_NUMBER, employee.getEmployeeNumber());
		
	}
	@Test
	void createEmployeeAnnualSalaryShouldBeInitialize() {
		//Arrange
		
		//Act
		Employee employee = new Employee(ANY_NAME, ANY_EMPLOYEE_NUMBER, ANY_ANNUAL_SALARY);
		
		//Assert
		assertEquals(ANY_ANNUAL_SALARY, employee.getAnnualSalary());
		
	}
	
	@Test
	void newEmployeeCantHaveASalaryOver100000() {
		//Arrange
		try {
		//Act
		Employee employee = new Employee(ANY_NAME, ANY_EMPLOYEE_NUMBER, NOT_VALID_ANNUAL_SALARY);
		}
		//Assert
		catch(InvalidParameterException ex) {
		assertEquals(Employee.INVALID_PARAMETER_NUMBER_1, ex.getMessage());
		}
	}

}
